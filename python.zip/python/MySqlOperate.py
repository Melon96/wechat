import pymysql

# 打开数据库连接，不指定数据库
conn = pymysql.connect('106.52.116.108', 'root', 'NIHAOHANS2019')
conn.select_db('wechat')

cur = conn.cursor()  # 获取游标

sql = "insert into sh_index values(%s,%s,%s,%s)"
cur.execute(sql, ('41', '14%', '41', '14%'))
print('添加语句受影响的行数：', sql)

cur.execute("select * from sh_index;")
while 1:
    res = cur.fetchone()
    if res is None:
        # 表示已经取完结果集
        break
    print(res)
cur.close()
conn.commit()
conn.close()
print('sql执行成功')
